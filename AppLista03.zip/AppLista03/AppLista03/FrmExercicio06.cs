﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class FrmExercicio06 : Form
    {
        public FrmExercicio06()
        {
            InitializeComponent();
        }

        private void btnCalcularPerimetro_Click(object sender, EventArgs e)
        {
            //Entrada
            float num = float.Parse(txtNum1.Text);
            float resultado;

            //Processo
            resultado = num * num * num;

            //Saída
            lblResultadoCubo.Text = "O valor do número ao cubo é igual a: " + resultado;
        }
    }
}

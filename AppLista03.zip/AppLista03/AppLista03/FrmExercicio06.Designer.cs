﻿namespace AppLista03
{
    partial class FrmExercicio06
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlToro = new System.Windows.Forms.Panel();
            this.lblExerc = new System.Windows.Forms.Label();
            this.btnCalcularPerimetro = new System.Windows.Forms.Button();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.lblNum1 = new System.Windows.Forms.Label();
            this.pnlBase = new System.Windows.Forms.Panel();
            this.lblResultadoCubo = new System.Windows.Forms.Label();
            this.pnlToro.SuspendLayout();
            this.pnlBase.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlToro
            // 
            this.pnlToro.BackColor = System.Drawing.Color.Salmon;
            this.pnlToro.Controls.Add(this.lblExerc);
            this.pnlToro.Location = new System.Drawing.Point(0, 0);
            this.pnlToro.Name = "pnlToro";
            this.pnlToro.Size = new System.Drawing.Size(687, 100);
            this.pnlToro.TabIndex = 52;
            // 
            // lblExerc
            // 
            this.lblExerc.AutoSize = true;
            this.lblExerc.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.lblExerc.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExerc.Location = new System.Drawing.Point(19, 27);
            this.lblExerc.Name = "lblExerc";
            this.lblExerc.Size = new System.Drawing.Size(246, 37);
            this.lblExerc.TabIndex = 47;
            this.lblExerc.Text = "EXERCÍCIO 06";
            // 
            // btnCalcularPerimetro
            // 
            this.btnCalcularPerimetro.BackColor = System.Drawing.Color.Silver;
            this.btnCalcularPerimetro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcularPerimetro.Location = new System.Drawing.Point(102, 226);
            this.btnCalcularPerimetro.Name = "btnCalcularPerimetro";
            this.btnCalcularPerimetro.Size = new System.Drawing.Size(139, 72);
            this.btnCalcularPerimetro.TabIndex = 49;
            this.btnCalcularPerimetro.Text = "Calcular cubo do número";
            this.btnCalcularPerimetro.UseVisualStyleBackColor = false;
            this.btnCalcularPerimetro.Click += new System.EventHandler(this.btnCalcularPerimetro_Click);
            // 
            // txtNum1
            // 
            this.txtNum1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNum1.Location = new System.Drawing.Point(102, 174);
            this.txtNum1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(216, 22);
            this.txtNum1.TabIndex = 48;
            // 
            // lblNum1
            // 
            this.lblNum1.AutoSize = true;
            this.lblNum1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNum1.Location = new System.Drawing.Point(97, 129);
            this.lblNum1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNum1.Name = "lblNum1";
            this.lblNum1.Size = new System.Drawing.Size(93, 25);
            this.lblNum1.TabIndex = 47;
            this.lblNum1.Text = "Número";
            // 
            // pnlBase
            // 
            this.pnlBase.BackColor = System.Drawing.Color.DodgerBlue;
            this.pnlBase.Controls.Add(this.lblResultadoCubo);
            this.pnlBase.Location = new System.Drawing.Point(0, 333);
            this.pnlBase.Name = "pnlBase";
            this.pnlBase.Size = new System.Drawing.Size(687, 125);
            this.pnlBase.TabIndex = 49;
            // 
            // lblResultadoCubo
            // 
            this.lblResultadoCubo.AutoSize = true;
            this.lblResultadoCubo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultadoCubo.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblResultadoCubo.Location = new System.Drawing.Point(52, 49);
            this.lblResultadoCubo.Name = "lblResultadoCubo";
            this.lblResultadoCubo.Size = new System.Drawing.Size(158, 25);
            this.lblResultadoCubo.TabIndex = 35;
            this.lblResultadoCubo.Text = "Valor ao cubo";
            // 
            // FrmExercicio06
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(683, 450);
            this.Controls.Add(this.pnlBase);
            this.Controls.Add(this.pnlToro);
            this.Controls.Add(this.btnCalcularPerimetro);
            this.Controls.Add(this.txtNum1);
            this.Controls.Add(this.lblNum1);
            this.Name = "FrmExercicio06";
            this.Text = "FrmExercicio06";
            this.pnlToro.ResumeLayout(false);
            this.pnlToro.PerformLayout();
            this.pnlBase.ResumeLayout(false);
            this.pnlBase.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlToro;
        private System.Windows.Forms.Label lblExerc;
        private System.Windows.Forms.Button btnCalcularPerimetro;
        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.Label lblNum1;
        private System.Windows.Forms.Panel pnlBase;
        private System.Windows.Forms.Label lblResultadoCubo;
    }
}
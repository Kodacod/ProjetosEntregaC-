﻿namespace AppLista03
{
    partial class FrmExercicio02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblResultadoDivisao = new System.Windows.Forms.Label();
            this.lblExerc = new System.Windows.Forms.Label();
            this.btnDivisao = new System.Windows.Forms.Button();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.lblNum2 = new System.Windows.Forms.Label();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.lblNum1 = new System.Windows.Forms.Label();
            this.pnlBase = new System.Windows.Forms.Panel();
            this.pnlToro = new System.Windows.Forms.Panel();
            this.pnlBase.SuspendLayout();
            this.pnlToro.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblResultadoDivisao
            // 
            this.lblResultadoDivisao.AutoSize = true;
            this.lblResultadoDivisao.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultadoDivisao.Location = new System.Drawing.Point(79, 10);
            this.lblResultadoDivisao.Name = "lblResultadoDivisao";
            this.lblResultadoDivisao.Size = new System.Drawing.Size(230, 25);
            this.lblResultadoDivisao.TabIndex = 23;
            this.lblResultadoDivisao.Text = "Quantidade em litros";
            // 
            // lblExerc
            // 
            this.lblExerc.AutoSize = true;
            this.lblExerc.BackColor = System.Drawing.Color.Yellow;
            this.lblExerc.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExerc.Location = new System.Drawing.Point(3, 14);
            this.lblExerc.Name = "lblExerc";
            this.lblExerc.Size = new System.Drawing.Size(246, 37);
            this.lblExerc.TabIndex = 22;
            this.lblExerc.Text = "EXERCÍCIO 02";
            // 
            // btnDivisao
            // 
            this.btnDivisao.BackColor = System.Drawing.Color.Silver;
            this.btnDivisao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDivisao.Location = new System.Drawing.Point(171, 246);
            this.btnDivisao.Name = "btnDivisao";
            this.btnDivisao.Size = new System.Drawing.Size(139, 72);
            this.btnDivisao.TabIndex = 20;
            this.btnDivisao.Text = "Divisão";
            this.btnDivisao.UseVisualStyleBackColor = false;
            this.btnDivisao.Click += new System.EventHandler(this.btnDivisao_Click);
            // 
            // txtNum2
            // 
            this.txtNum2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNum2.Location = new System.Drawing.Point(137, 204);
            this.txtNum2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(216, 22);
            this.txtNum2.TabIndex = 16;
            // 
            // lblNum2
            // 
            this.lblNum2.AutoSize = true;
            this.lblNum2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNum2.Location = new System.Drawing.Point(132, 176);
            this.lblNum2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNum2.Name = "lblNum2";
            this.lblNum2.Size = new System.Drawing.Size(163, 25);
            this.lblNum2.TabIndex = 15;
            this.lblNum2.Text = "Valor gasolina";
            // 
            // txtNum1
            // 
            this.txtNum1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNum1.Location = new System.Drawing.Point(137, 140);
            this.txtNum1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(216, 22);
            this.txtNum1.TabIndex = 14;
            // 
            // lblNum1
            // 
            this.lblNum1.AutoSize = true;
            this.lblNum1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNum1.Location = new System.Drawing.Point(132, 112);
            this.lblNum1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNum1.Name = "lblNum1";
            this.lblNum1.Size = new System.Drawing.Size(154, 25);
            this.lblNum1.TabIndex = 13;
            this.lblNum1.Text = "Valor a pagar";
            // 
            // pnlBase
            // 
            this.pnlBase.BackColor = System.Drawing.Color.YellowGreen;
            this.pnlBase.Controls.Add(this.lblResultadoDivisao);
            this.pnlBase.Location = new System.Drawing.Point(1, 359);
            this.pnlBase.Name = "pnlBase";
            this.pnlBase.Size = new System.Drawing.Size(528, 95);
            this.pnlBase.TabIndex = 24;
            // 
            // pnlToro
            // 
            this.pnlToro.BackColor = System.Drawing.Color.Gold;
            this.pnlToro.Controls.Add(this.lblExerc);
            this.pnlToro.Location = new System.Drawing.Point(1, -5);
            this.pnlToro.Name = "pnlToro";
            this.pnlToro.Size = new System.Drawing.Size(528, 93);
            this.pnlToro.TabIndex = 25;
            // 
            // FrmExercicio02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(515, 450);
            this.Controls.Add(this.btnDivisao);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.lblNum2);
            this.Controls.Add(this.txtNum1);
            this.Controls.Add(this.lblNum1);
            this.Controls.Add(this.pnlBase);
            this.Controls.Add(this.pnlToro);
            this.Name = "FrmExercicio02";
            this.Text = "FrmExercicio02";
            this.pnlBase.ResumeLayout(false);
            this.pnlBase.PerformLayout();
            this.pnlToro.ResumeLayout(false);
            this.pnlToro.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblResultadoDivisao;
        private System.Windows.Forms.Label lblExerc;
        private System.Windows.Forms.Button btnDivisao;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.Label lblNum2;
        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.Label lblNum1;
        private System.Windows.Forms.Panel pnlBase;
        private System.Windows.Forms.Panel pnlToro;
    }
}
﻿namespace AppLista03
{
    partial class FrmExercicio07
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlToro = new System.Windows.Forms.Panel();
            this.lblExerc = new System.Windows.Forms.Label();
            this.btnVlrCamisa = new System.Windows.Forms.Button();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.lblNum1 = new System.Windows.Forms.Label();
            this.pnlBase = new System.Windows.Forms.Panel();
            this.lblResultadoVlrCamisa = new System.Windows.Forms.Label();
            this.lblNum2 = new System.Windows.Forms.Label();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.lblNum3 = new System.Windows.Forms.Label();
            this.txtNum3 = new System.Windows.Forms.TextBox();
            this.pnlToro.SuspendLayout();
            this.pnlBase.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlToro
            // 
            this.pnlToro.BackColor = System.Drawing.Color.Crimson;
            this.pnlToro.Controls.Add(this.lblExerc);
            this.pnlToro.Location = new System.Drawing.Point(1, 0);
            this.pnlToro.Name = "pnlToro";
            this.pnlToro.Size = new System.Drawing.Size(687, 100);
            this.pnlToro.TabIndex = 56;
            // 
            // lblExerc
            // 
            this.lblExerc.AutoSize = true;
            this.lblExerc.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.lblExerc.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExerc.Location = new System.Drawing.Point(19, 27);
            this.lblExerc.Name = "lblExerc";
            this.lblExerc.Size = new System.Drawing.Size(246, 37);
            this.lblExerc.TabIndex = 47;
            this.lblExerc.Text = "EXERCÍCIO 07";
            // 
            // btnVlrCamisa
            // 
            this.btnVlrCamisa.BackColor = System.Drawing.Color.Silver;
            this.btnVlrCamisa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVlrCamisa.Location = new System.Drawing.Point(378, 218);
            this.btnVlrCamisa.Name = "btnVlrCamisa";
            this.btnVlrCamisa.Size = new System.Drawing.Size(139, 72);
            this.btnVlrCamisa.TabIndex = 55;
            this.btnVlrCamisa.Text = "Calcular valor camisa";
            this.btnVlrCamisa.UseVisualStyleBackColor = false;
            this.btnVlrCamisa.Click += new System.EventHandler(this.btnVlrCamisa_Click);
            // 
            // txtNum1
            // 
            this.txtNum1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNum1.Location = new System.Drawing.Point(103, 140);
            this.txtNum1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(216, 22);
            this.txtNum1.TabIndex = 54;
            // 
            // lblNum1
            // 
            this.lblNum1.AutoSize = true;
            this.lblNum1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNum1.Location = new System.Drawing.Point(98, 112);
            this.lblNum1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNum1.Name = "lblNum1";
            this.lblNum1.Size = new System.Drawing.Size(112, 25);
            this.lblNum1.TabIndex = 53;
            this.lblNum1.Text = "Camisa P";
            // 
            // pnlBase
            // 
            this.pnlBase.BackColor = System.Drawing.Color.Crimson;
            this.pnlBase.Controls.Add(this.lblResultadoVlrCamisa);
            this.pnlBase.Location = new System.Drawing.Point(1, 330);
            this.pnlBase.Name = "pnlBase";
            this.pnlBase.Size = new System.Drawing.Size(687, 125);
            this.pnlBase.TabIndex = 50;
            // 
            // lblResultadoVlrCamisa
            // 
            this.lblResultadoVlrCamisa.AutoSize = true;
            this.lblResultadoVlrCamisa.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultadoVlrCamisa.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblResultadoVlrCamisa.Location = new System.Drawing.Point(52, 49);
            this.lblResultadoVlrCamisa.Name = "lblResultadoVlrCamisa";
            this.lblResultadoVlrCamisa.Size = new System.Drawing.Size(152, 25);
            this.lblResultadoVlrCamisa.TabIndex = 35;
            this.lblResultadoVlrCamisa.Text = "Valor Camisa";
            // 
            // lblNum2
            // 
            this.lblNum2.AutoSize = true;
            this.lblNum2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNum2.Location = new System.Drawing.Point(99, 177);
            this.lblNum2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNum2.Name = "lblNum2";
            this.lblNum2.Size = new System.Drawing.Size(116, 25);
            this.lblNum2.TabIndex = 57;
            this.lblNum2.Text = "Camisa M";
            // 
            // txtNum2
            // 
            this.txtNum2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNum2.Location = new System.Drawing.Point(103, 205);
            this.txtNum2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(216, 22);
            this.txtNum2.TabIndex = 58;
            // 
            // lblNum3
            // 
            this.lblNum3.AutoSize = true;
            this.lblNum3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNum3.Location = new System.Drawing.Point(99, 240);
            this.lblNum3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNum3.Name = "lblNum3";
            this.lblNum3.Size = new System.Drawing.Size(114, 25);
            this.lblNum3.TabIndex = 59;
            this.lblNum3.Text = "Camisa G";
            // 
            // txtNum3
            // 
            this.txtNum3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNum3.Location = new System.Drawing.Point(103, 268);
            this.txtNum3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtNum3.Name = "txtNum3";
            this.txtNum3.Size = new System.Drawing.Size(216, 22);
            this.txtNum3.TabIndex = 60;
            // 
            // FrmExercicio07
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Pink;
            this.ClientSize = new System.Drawing.Size(686, 450);
            this.Controls.Add(this.txtNum3);
            this.Controls.Add(this.lblNum3);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.lblNum2);
            this.Controls.Add(this.pnlBase);
            this.Controls.Add(this.pnlToro);
            this.Controls.Add(this.btnVlrCamisa);
            this.Controls.Add(this.txtNum1);
            this.Controls.Add(this.lblNum1);
            this.Name = "FrmExercicio07";
            this.Text = "FrmExercicio07";
            this.pnlToro.ResumeLayout(false);
            this.pnlToro.PerformLayout();
            this.pnlBase.ResumeLayout(false);
            this.pnlBase.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlToro;
        private System.Windows.Forms.Label lblExerc;
        private System.Windows.Forms.Button btnVlrCamisa;
        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.Label lblNum1;
        private System.Windows.Forms.Panel pnlBase;
        private System.Windows.Forms.Label lblResultadoVlrCamisa;
        private System.Windows.Forms.Label lblNum2;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.Label lblNum3;
        private System.Windows.Forms.TextBox txtNum3;
    }
}
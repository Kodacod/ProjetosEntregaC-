﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class FrmExercicio01 : Form
    {
        public FrmExercicio01()
        {
            InitializeComponent();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            //Entrada
            float num1 = float.Parse(txtNum1.Text);
            float num3 = float.Parse(txtNum3.Text);
            float soma;

            //Processo
            soma = num1 + num3;
            
            //Saída
            lblResultadoSoma.Text = "Soma igual a " + soma;
        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            //Entrada
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float media;

            //Processo
            media = (num1 + num2 + num3) / 3;

            //Saída
            lblResultadoMedia.Text = "Média igual a " + media;
        }

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            //Entrada
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float total, porcNum1, porcNum2, porcNum3;

            //Processo
            total = num1 + num2 + num3; //100%
            porcNum1 = num1 / total * 100;
            porcNum2 = num2 / total * 100;
            porcNum3 = num3 / total * 100;

            //Saída
            lblResultadoPorcentagem.Text = "Resultado Num1 é " + porcNum1 + "% - " + "Resultado Num2 é " + porcNum2 + "% - " + "Resultado Num3 é " + porcNum3 + "%.";
        }
    }
}

﻿namespace AppLista03
{
    partial class FrmExercicio03
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblResultadoMultiplicacao = new System.Windows.Forms.Label();
            this.lblExerc = new System.Windows.Forms.Label();
            this.btnMultiplicacao = new System.Windows.Forms.Button();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.lblNum1 = new System.Windows.Forms.Label();
            this.pnlToro = new System.Windows.Forms.Panel();
            this.pnlBase = new System.Windows.Forms.Panel();
            this.pnlBase.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblResultadoMultiplicacao
            // 
            this.lblResultadoMultiplicacao.AutoSize = true;
            this.lblResultadoMultiplicacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultadoMultiplicacao.Location = new System.Drawing.Point(100, 20);
            this.lblResultadoMultiplicacao.Name = "lblResultadoMultiplicacao";
            this.lblResultadoMultiplicacao.Size = new System.Drawing.Size(154, 25);
            this.lblResultadoMultiplicacao.TabIndex = 30;
            this.lblResultadoMultiplicacao.Text = "Valor a pagar";
            // 
            // lblExerc
            // 
            this.lblExerc.AutoSize = true;
            this.lblExerc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.lblExerc.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExerc.Location = new System.Drawing.Point(12, 26);
            this.lblExerc.Name = "lblExerc";
            this.lblExerc.Size = new System.Drawing.Size(246, 37);
            this.lblExerc.TabIndex = 29;
            this.lblExerc.Text = "EXERCÍCIO 03";
            // 
            // btnMultiplicacao
            // 
            this.btnMultiplicacao.BackColor = System.Drawing.Color.Silver;
            this.btnMultiplicacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMultiplicacao.Location = new System.Drawing.Point(94, 267);
            this.btnMultiplicacao.Name = "btnMultiplicacao";
            this.btnMultiplicacao.Size = new System.Drawing.Size(139, 72);
            this.btnMultiplicacao.TabIndex = 28;
            this.btnMultiplicacao.Text = "Multiplicação";
            this.btnMultiplicacao.UseVisualStyleBackColor = false;
            this.btnMultiplicacao.Click += new System.EventHandler(this.btnMultiplicacao_Click);
            // 
            // txtNum1
            // 
            this.txtNum1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNum1.Location = new System.Drawing.Point(94, 130);
            this.txtNum1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(216, 22);
            this.txtNum1.TabIndex = 25;
            // 
            // lblNum1
            // 
            this.lblNum1.AutoSize = true;
            this.lblNum1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNum1.Location = new System.Drawing.Point(89, 102);
            this.lblNum1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNum1.Name = "lblNum1";
            this.lblNum1.Size = new System.Drawing.Size(65, 25);
            this.lblNum1.TabIndex = 24;
            this.lblNum1.Text = "Peso";
            // 
            // pnlToro
            // 
            this.pnlToro.BackColor = System.Drawing.Color.LightGreen;
            this.pnlToro.Location = new System.Drawing.Point(-11, 0);
            this.pnlToro.Name = "pnlToro";
            this.pnlToro.Size = new System.Drawing.Size(570, 86);
            this.pnlToro.TabIndex = 31;
            // 
            // pnlBase
            // 
            this.pnlBase.BackColor = System.Drawing.Color.LightGreen;
            this.pnlBase.Controls.Add(this.lblResultadoMultiplicacao);
            this.pnlBase.Location = new System.Drawing.Point(-11, 370);
            this.pnlBase.Name = "pnlBase";
            this.pnlBase.Size = new System.Drawing.Size(582, 86);
            this.pnlBase.TabIndex = 32;
            // 
            // FrmExercicio03
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.ClientSize = new System.Drawing.Size(551, 450);
            this.Controls.Add(this.pnlBase);
            this.Controls.Add(this.lblExerc);
            this.Controls.Add(this.btnMultiplicacao);
            this.Controls.Add(this.txtNum1);
            this.Controls.Add(this.lblNum1);
            this.Controls.Add(this.pnlToro);
            this.Name = "FrmExercicio03";
            this.Text = "FrmExercicio03";
            this.pnlBase.ResumeLayout(false);
            this.pnlBase.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblResultadoMultiplicacao;
        private System.Windows.Forms.Label lblExerc;
        private System.Windows.Forms.Button btnMultiplicacao;
        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.Label lblNum1;
        private System.Windows.Forms.Panel pnlToro;
        private System.Windows.Forms.Panel pnlBase;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class FrmExercicio07 : Form
    {
        public FrmExercicio07()
        {
            InitializeComponent();
        }

        private void btnVlrCamisa_Click(object sender, EventArgs e)
        {
            //Entrada
            float CamisaP = float.Parse(txtNum1.Text);
            float CamisaM
        }
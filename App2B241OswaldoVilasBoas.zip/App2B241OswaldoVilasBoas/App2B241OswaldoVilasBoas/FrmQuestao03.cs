﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace App2B241OswaldoVilasBoas
{
    public partial class FrmQuestao03 : Form
    {
        public FrmQuestao03()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Entrada
            float vlrpagar = float.Parse(txtVlrpagar.Text);
            float resultado;

            //Processo
            resultado = (vlrpagar * 10 / 100) + vlrpagar;

            //Saída
            lblResultado.Text = "O valor total a pagar é igua a " + resultado.ToString("C");
        }
    }
}

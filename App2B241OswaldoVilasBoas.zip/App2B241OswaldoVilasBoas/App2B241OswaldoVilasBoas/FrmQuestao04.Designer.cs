﻿namespace App2B241OswaldoVilasBoas
{
    partial class FrmQuestao04
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblQuilos = new System.Windows.Forms.Label();
            this.lblGramas = new System.Windows.Forms.Label();
            this.txtQuilos = new System.Windows.Forms.TextBox();
            this.txtGramas = new System.Windows.Forms.TextBox();
            this.lblResultado = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblQuilos
            // 
            this.lblQuilos.AutoSize = true;
            this.lblQuilos.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuilos.Location = new System.Drawing.Point(43, 55);
            this.lblQuilos.Name = "lblQuilos";
            this.lblQuilos.Size = new System.Drawing.Size(187, 31);
            this.lblQuilos.TabIndex = 0;
            this.lblQuilos.Text = "Quilos ração:";
            // 
            // lblGramas
            // 
            this.lblGramas.AutoSize = true;
            this.lblGramas.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGramas.Location = new System.Drawing.Point(43, 159);
            this.lblGramas.Name = "lblGramas";
            this.lblGramas.Size = new System.Drawing.Size(222, 31);
            this.lblGramas.TabIndex = 1;
            this.lblGramas.Text = "Gramas porção:";
            // 
            // txtQuilos
            // 
            this.txtQuilos.Location = new System.Drawing.Point(49, 99);
            this.txtQuilos.Name = "txtQuilos";
            this.txtQuilos.Size = new System.Drawing.Size(371, 20);
            this.txtQuilos.TabIndex = 2;
            // 
            // txtGramas
            // 
            this.txtGramas.Location = new System.Drawing.Point(49, 217);
            this.txtGramas.Name = "txtGramas";
            this.txtGramas.Size = new System.Drawing.Size(371, 20);
            this.txtGramas.TabIndex = 3;
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.Location = new System.Drawing.Point(43, 373);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(155, 31);
            this.lblResultado.TabIndex = 4;
            this.lblResultado.Text = "Resultado:";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(49, 271);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(143, 58);
            this.btnCalcular.TabIndex = 5;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // FrmQuestao04
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.txtGramas);
            this.Controls.Add(this.txtQuilos);
            this.Controls.Add(this.lblGramas);
            this.Controls.Add(this.lblQuilos);
            this.Name = "FrmQuestao04";
            this.Text = "FrmQuestao04";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblQuilos;
        private System.Windows.Forms.Label lblGramas;
        private System.Windows.Forms.TextBox txtQuilos;
        private System.Windows.Forms.TextBox txtGramas;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Button btnCalcular;
    }
}
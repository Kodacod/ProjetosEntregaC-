﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace App2B241OswaldoVilasBoas
{
    public partial class FrmQuestao04 : Form
    {
        public FrmQuestao04()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Entrada
            float quilos = float.Parse(txtQuilos.Text);
            float gramas = float.Parse(txtGramas.Text);
            float resultado;

            //Processo
            resultado = quilos * 1000 / gramas;

            //Saída
            lblResultado.Text = "A quantidade de porções é igual a " + resultado;
        }
    }
}

﻿namespace App2B241OswaldoVilasBoas
{
    partial class FrmQuestao02
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmQuestao02));
            this.pnlTopo = new System.Windows.Forms.Panel();
            this.lblCadastro = new System.Windows.Forms.Label();
            this.pnlBase = new System.Windows.Forms.Panel();
            this.pnlMeio = new System.Windows.Forms.Panel();
            this.btnCadastrar = new System.Windows.Forms.Button();
            this.txtLancamento = new System.Windows.Forms.TextBox();
            this.txtEdicao = new System.Windows.Forms.TextBox();
            this.txtEditora = new System.Windows.Forms.TextBox();
            this.txtTitulo = new System.Windows.Forms.TextBox();
            this.lblLancamento = new System.Windows.Forms.Label();
            this.lblEdicao = new System.Windows.Forms.Label();
            this.lblEditora = new System.Windows.Forms.Label();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.pnlTopo.SuspendLayout();
            this.pnlMeio.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTopo
            // 
            this.pnlTopo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(145)))), ((int)(((byte)(108)))));
            this.pnlTopo.Controls.Add(this.lblCadastro);
            this.pnlTopo.Location = new System.Drawing.Point(-5, -3);
            this.pnlTopo.Name = "pnlTopo";
            this.pnlTopo.Size = new System.Drawing.Size(806, 77);
            this.pnlTopo.TabIndex = 0;
            // 
            // lblCadastro
            // 
            this.lblCadastro.AutoSize = true;
            this.lblCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCadastro.Location = new System.Drawing.Point(12, 15);
            this.lblCadastro.Name = "lblCadastro";
            this.lblCadastro.Size = new System.Drawing.Size(365, 55);
            this.lblCadastro.TabIndex = 0;
            this.lblCadastro.Text = "Cadastro Livro:";
            // 
            // pnlBase
            // 
            this.pnlBase.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(145)))), ((int)(((byte)(108)))));
            this.pnlBase.Location = new System.Drawing.Point(-5, 374);
            this.pnlBase.Name = "pnlBase";
            this.pnlBase.Size = new System.Drawing.Size(806, 77);
            this.pnlBase.TabIndex = 1;
            // 
            // pnlMeio
            // 
            this.pnlMeio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(106)))), ((int)(((byte)(79)))));
            this.pnlMeio.Controls.Add(this.btnCadastrar);
            this.pnlMeio.Controls.Add(this.txtLancamento);
            this.pnlMeio.Controls.Add(this.txtEdicao);
            this.pnlMeio.Controls.Add(this.txtEditora);
            this.pnlMeio.Controls.Add(this.txtTitulo);
            this.pnlMeio.Controls.Add(this.lblLancamento);
            this.pnlMeio.Controls.Add(this.lblEdicao);
            this.pnlMeio.Controls.Add(this.lblEditora);
            this.pnlMeio.Controls.Add(this.lblTitulo);
            this.pnlMeio.Location = new System.Drawing.Point(-5, 80);
            this.pnlMeio.Name = "pnlMeio";
            this.pnlMeio.Size = new System.Drawing.Size(806, 288);
            this.pnlMeio.TabIndex = 1;
            // 
            // btnCadastrar
            // 
            this.btnCadastrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(145)))), ((int)(((byte)(108)))));
            this.btnCadastrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastrar.ForeColor = System.Drawing.SystemColors.Control;
            this.btnCadastrar.Location = new System.Drawing.Point(563, 123);
            this.btnCadastrar.Name = "btnCadastrar";
            this.btnCadastrar.Size = new System.Drawing.Size(184, 67);
            this.btnCadastrar.TabIndex = 8;
            this.btnCadastrar.Text = "Cadastrar";
            this.btnCadastrar.UseVisualStyleBackColor = false;
            // 
            // txtLancamento
            // 
            this.txtLancamento.Location = new System.Drawing.Point(22, 250);
            this.txtLancamento.Name = "txtLancamento";
            this.txtLancamento.Size = new System.Drawing.Size(443, 20);
            this.txtLancamento.TabIndex = 7;
            // 
            // txtEdicao
            // 
            this.txtEdicao.Location = new System.Drawing.Point(22, 190);
            this.txtEdicao.Name = "txtEdicao";
            this.txtEdicao.Size = new System.Drawing.Size(443, 20);
            this.txtEdicao.TabIndex = 6;
            // 
            // txtEditora
            // 
            this.txtEditora.Location = new System.Drawing.Point(22, 127);
            this.txtEditora.Name = "txtEditora";
            this.txtEditora.Size = new System.Drawing.Size(443, 20);
            this.txtEditora.TabIndex = 5;
            // 
            // txtTitulo
            // 
            this.txtTitulo.Location = new System.Drawing.Point(22, 65);
            this.txtTitulo.Name = "txtTitulo";
            this.txtTitulo.Size = new System.Drawing.Size(443, 20);
            this.txtTitulo.TabIndex = 4;
            // 
            // lblLancamento
            // 
            this.lblLancamento.AutoSize = true;
            this.lblLancamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLancamento.ForeColor = System.Drawing.SystemColors.Control;
            this.lblLancamento.Location = new System.Drawing.Point(22, 222);
            this.lblLancamento.Name = "lblLancamento";
            this.lblLancamento.Size = new System.Drawing.Size(147, 25);
            this.lblLancamento.TabIndex = 3;
            this.lblLancamento.Text = "Lançamento:";
            // 
            // lblEdicao
            // 
            this.lblEdicao.AutoSize = true;
            this.lblEdicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEdicao.ForeColor = System.Drawing.SystemColors.Control;
            this.lblEdicao.Location = new System.Drawing.Point(22, 162);
            this.lblEdicao.Name = "lblEdicao";
            this.lblEdicao.Size = new System.Drawing.Size(91, 25);
            this.lblEdicao.TabIndex = 2;
            this.lblEdicao.Text = "Edição:";
            // 
            // lblEditora
            // 
            this.lblEditora.AutoSize = true;
            this.lblEditora.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditora.ForeColor = System.Drawing.SystemColors.Control;
            this.lblEditora.Location = new System.Drawing.Point(22, 99);
            this.lblEditora.Name = "lblEditora";
            this.lblEditora.Size = new System.Drawing.Size(94, 25);
            this.lblEditora.TabIndex = 1;
            this.lblEditora.Text = "Editora:";
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.SystemColors.Control;
            this.lblTitulo.Location = new System.Drawing.Point(22, 37);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(78, 25);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Título:";
            // 
            // FrmQuestao02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pnlMeio);
            this.Controls.Add(this.pnlBase);
            this.Controls.Add(this.pnlTopo);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmQuestao02";
            this.Text = "Cadastro Livro";
            this.pnlTopo.ResumeLayout(false);
            this.pnlTopo.PerformLayout();
            this.pnlMeio.ResumeLayout(false);
            this.pnlMeio.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTopo;
        private System.Windows.Forms.Panel pnlBase;
        private System.Windows.Forms.Panel pnlMeio;
        private System.Windows.Forms.Label lblCadastro;
        private System.Windows.Forms.Button btnCadastrar;
        private System.Windows.Forms.TextBox txtLancamento;
        private System.Windows.Forms.TextBox txtEdicao;
        private System.Windows.Forms.TextBox txtEditora;
        private System.Windows.Forms.TextBox txtTitulo;
        private System.Windows.Forms.Label lblLancamento;
        private System.Windows.Forms.Label lblEdicao;
        private System.Windows.Forms.Label lblEditora;
        private System.Windows.Forms.Label lblTitulo;
    }
}


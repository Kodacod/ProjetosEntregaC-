﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace REVISAO_EXERCICIO_PROVA
{
    public partial class FrmQuestao01 : Form
    {
        public FrmQuestao01()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Entrada
            float valor1 = float.Parse(txtValor1.Text);
            float valor2 = float.Parse(txtValor2.Text);
            float valor3 = float.Parse(txtValor3.Text);
            float resultado1, resultado2, resultado3;


            //Processo
            resultado1 = (valor1 * 0.1f) + valor1;
            resultado2 = (valor2 * 0.1f) + valor2;
            resultado3 = (valor3 * 0.1f) + valor3;

            //Saída
            lblResultado1.Text = "O resultado da operação é igual a: " + resultado1;
            lblResultado2.Text = "O resultado da operação é igual a: " + resultado2;
            lblResultado3.Text = "O resultado da operação é igual a: " + resultado3;
        }
    }
}

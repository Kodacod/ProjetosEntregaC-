﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Mensagem
{
    public partial class FrmEnvioMensagem : Form
    {
        public FrmEnvioMensagem()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei na label Inteiro");
        }

        private void label2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei na label Decimal");
        }

        private void FrmEnvioMensagem_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Eai Bão? :)");
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("BU!");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Todos os seus dados serão  em 3 2 1. Dados apagados com sucesso.");
        }

        private void lblTexto_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei na label Texto");
        }

        private void lblBooleano_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei na Label Booleano");
        }

        private void txtInteiro_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Para de escrever aqui po!");
        }

        private void txtDecimal_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Não pode escrever aqui também não!");
        }

        private void txtTexto_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Ja disse pra não escr- ah não vou repetir.");
        }

        private void txtBooleano_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("AAAAAAAAAAAAAAAAAAHHHHHHHHHHH!!!!");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppCalculadora
{
    public partial class FrmCalculadora : Form
    {
        public FrmCalculadora()
        {
            InitializeComponent();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {   
            //Variáveis na tela
            float valorNumero1 = float.Parse(txtBox1.Text);
            float valorNumero2 = float.Parse(txtBox2.Text);
            float soma;

            //Processamento
            soma = valorNumero1 + valorNumero2;

            //Saída
            MessageBox.Show("O resultado da soma é igual a: " + soma);
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            //Variávei na tela
            float valorNumero1 = float.Parse(txtBox1.Text);
            float valorNumero2 = float.Parse(txtBox2.Text);
            float subtracao;

            //Processamento
            subtracao = valorNumero1 - valorNumero2;

            //Saída
            MessageBox.Show("O resultado da subtração é igual: " + subtracao);
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            //Variáveis na tela
            float valorNumero1 = float.Parse(txtBox1.Text);
            float valorNumero2 = float.Parse(txtBox2.Text);
            float multiplicacao;

            //Processamento
            multiplicacao = valorNumero1 * valorNumero2;

            //Saída
            MessageBox.Show("O resultado da multiplicação é igual a: " + multiplicacao);
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            //Variáveis na Tela
            float valorNumero1 = float.Parse(txtBox1.Text);
            float valorNumero2 = float.Parse(txtBox2.Text);
            float divisao;

            //Processamento
            divisao = valorNumero1 / valorNumero2;

            //Saída
            MessageBox.Show("O resultado da divisão é igual a: " + divisao);


        }
    }
}
